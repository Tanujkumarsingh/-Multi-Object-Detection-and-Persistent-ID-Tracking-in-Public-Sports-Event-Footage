# Technical Report: Multi-Object Detection and Persistent ID Tracking
## AI / Computer Vision Assignment

**Author:** [Your Name]  
**Date:** April 2026  
**Video:** Aerial basketball tournament footage — 1344×756 px, 8 fps, 58 s  

---

## 1. Problem Statement

The task is to detect all moving subjects in a publicly available sports video and assign each of them a persistent unique ID that remains stable across the entire video, handling real-world challenges including occlusion, motion, similar appearance, and camera motion.

---

## 2. Video and Dataset

The selected video is an aerial/drone recording of a public basketball tournament ("明德双语学校杯 2017") held on an outdoor multi-court facility. It was provided as `video for assignment.mp4`.

- **Resolution:** 1344 × 756 pixels  
- **Frame rate:** 8 fps  
- **Duration:** ~58 seconds (464 frames)  
- **Subjects:** 20–25 players, spectators, and officials across two courts  
- **Challenges:** similar-coloured jerseys, occlusion at the court boundary, stationary and moving subjects mixed, slight aerial perspective distortion

---

## 3. Detection Approach

### 3.1 Why Not HOG or Standard YOLOv8?

Standard pedestrian detectors (HOG + SVM, YOLOv8-COCO) are trained on upright, near-frontal views of people. In aerial footage, people appear much smaller (~50–100 px tall), foreshortened, and without typical head-shoulder silhouettes. Initial testing confirmed near-zero recall for HOG and unavailability of YOLO weights in the offline environment.

### 3.2 Colour-Blob Segmentation Detector

**Pipeline:**

1. Convert frame to HSV colour space  
2. Mask out known court surface colours (red: H∈[0°,12°]∪[155°,180°]; blue: H∈[88°,135°]; white lines; green trees/grass)  
3. Invert the mask → candidate foreground pixels  
4. Run MOG2 background subtractor in parallel → motion mask  
5. Combine foreground and dilated motion masks with bitwise-OR  
6. Morphological opening + closing (4×4, 9×9 elliptical kernels) to remove noise and fill holes  
7. Extract contours and filter by: area ∈ [350, 14,000] px², aspect ratio ∈ [0.25, 4.5]  
8. Apply IoU-based NMS (threshold 0.30) to remove duplicates  

**Confidence scoring:** Each blob receives a confidence score based on its area (size relative to expected person size) and aspect ratio (closeness to ~1.8 expected for a standing person viewed from above):  
```
conf = 0.50 × base + 0.30 × size_score + 0.20 × aspect_score
```

This approach is well-calibrated to the aerial basketball scene and requires no pre-trained model weights.

---

## 4. Tracking Algorithm

### 4.1 Kalman Filter per Track

Each track maintains a 7-dimensional state vector:
```
x = [cx, cy, area, aspect_ratio, vx, vy, v_area]ᵀ
```
A constant-velocity motion model (state-transition matrix F) predicts the next position. Process noise is set low (Q[4:,4:] × 0.01) to produce smooth predictions; measurement noise on scale/ratio (R[2:,2:] × 10) allows bounding-box scale to vary without corrupting the position estimate.

### 4.2 Two-Round ByteTrack Matching

Inspired by [Zhang et al. 2022], matching is split into two rounds:

**Round 1 — High-confidence detections (conf ≥ 0.50) vs all active tracks:**  
```
cost = 0.65 × (1 − IoU) + 0.35 × appearance_cost
```
The Hungarian algorithm (O(n³) scipy `linear_sum_assignment`) finds the globally optimal assignment. Pairs with cost > 1 − IoU_threshold (0.22) are rejected.

**Round 2 — Low-confidence detections (conf ≥ 0.15) vs unmatched tracks:**  
```
cost = 1 − IoU only
```
This round recovers tracks that were temporarily obscured and whose detections are weak (partially occluded, or on a boundary between court and sideline).

### 4.3 Track Lifecycle

| Event | Condition |
|-------|-----------|
| **Spawn** | Unmatched high-conf detection → new tentative track |
| **Promote** | Track hits ≥ `min_hits=3` → ID label displayed |
| **Predict** | Every frame, the Kalman filter predicts position even if no detection matched |
| **Delete** | `time_since_update > max_age=40` frames without a match |

### 4.4 Appearance Re-ID

Each confirmed track maintains an **exponentially-smoothed 96-D HSV colour histogram** (32 bins per channel, EMA α=0.25). At match time, histogram intersection similarity is computed and blended with the IoU cost (weight 0.35). This helps the tracker correctly re-associate a player who re-enters from behind an obstruction and would otherwise receive a new ID.

---

## 5. ID Consistency Strategy

| Challenge | Strategy |
|-----------|----------|
| **Short occlusion** | Track kept alive for 40 frames via Kalman prediction |
| **Re-entry** | Appearance cost guides Hungarian matching to the correct track |
| **Rapid movement** | Velocity terms in Kalman state adapt; IoU between predicted and detected box remains high |
| **Similar appearance** | HSV histogram captures dominant jersey colour; EMA smoothing prevents rapid drift |
| **False positives** | `min_hits=3` gate prevents single-frame noise from spawning visible IDs |

---

## 6. Results

| Metric | Value |
|--------|-------|
| **Total unique IDs** | 21 |
| **Max simultaneous tracks** | 16 |
| **Mean active tracks/frame** | 8.6 |
| **Median track lifetime** | 14.4 s |
| **Mean track lifetime** | 23.9 s |
| **Processing speed** | ~8 fps (matches source frame rate; real-time on CPU) |

The tracker successfully maintained persistent IDs across the full 58-second clip for the majority of subjects. Long-lived tracks (IDs 1–10) remained stable through occlusion events at the court boundary. The movement heatmap and trajectory map confirm that the active playing area (centre court) received the densest coverage, consistent with expected basketball gameplay.

---

## 7. Challenges Observed

1. **Background-boundary false positives:** The upper segment of the frame (trees, fence, scoreboard) produced some false foreground blobs due to lighting variation. These were partially suppressed by the green-channel mask but are not fully eliminated.

2. **Clustered players:** When 3–5 players group together (e.g. at a rebound or free-throw), individual blobs merge into one large contour. The tracker sometimes assigns a single ID to a group, then re-splits when they separate — causing a new ID for one of the players.

3. **Stationary sideline players:** Players sitting motionless on the sidelines are missed by the MOG2 motion cue; the colour segmentation path still catches most of them when they contrast against the red court.

4. **Camera pan at seconds 20–35:** A slow camera pan causes the Kalman predictions to drift slightly; the IoU cost between predicted and detected boxes increases, slightly raising the risk of mis-assignment.

---

## 8. Possible Improvements

1. **Deep detector (aerial-tuned YOLO):** Fine-tuning YOLOv8 on an aerial pedestrian dataset would dramatically improve precision and recall at the player scale and reduce false positives near the court boundary.

2. **Deep Re-ID:** Replacing HSV histograms with an OSNet or BoT-SORT embedding network would resolve ID switches caused by players in the same jersey colour.

3. **Global Motion Compensation (GMC):** Estimating a frame-to-frame homography and compensating the Kalman prediction would eliminate drift during camera pan.

4. **Court homography (bird's-eye projection):** Mapping detections onto a normalised 2D court diagram would enable tactical analysis, speed estimation, and team-zone heatmaps.

5. **Evaluation (HOTA / MOTA / IDF1):** Annotating 200 frames as ground truth would allow quantitative benchmarking and parameter tuning.

---

## 9. Conclusion

The implemented pipeline demonstrates that reliable multi-object detection and persistent ID tracking is achievable on aerial sports footage without any pre-trained neural network weights, using a carefully designed colour-blob detector and a ByteTrack-style Kalman + Hungarian tracker. The system processes the full 58-second video in real time, assigning 21 unique IDs with a median lifetime of 14 seconds and handling occlusion, motion blur, and clustering through a combination of Kalman prediction, two-round matching, and colour-histogram re-identification.

---

## References

- Zhang, Y. et al. (2022). *ByteTrack: Multi-Object Tracking by Associating Every Detection Box.* ECCV 2022.  
- Bewley, A. et al. (2016). *SORT: Simple Online and Realtime Tracking.* ICASSP 2016.  
- Labbé, R. *FilterPy: Kalman Filters in Python.* https://github.com/rlabbe/filterpy  
- OpenCV documentation: Background Subtraction (MOG2), HOGDescriptor, Hungarian algorithm.
