# Multi-Object Detection & Persistent ID Tracking
### AI / Computer Vision Assignment — Public Sports Footage

---

## Video Used

| Field | Detail |
|-------|--------|
| **File** | `video for assignment.mp4` (provided) |
| **Content** | Aerial/drone view of a basketball tournament — "明德双语学校杯 2017" |
| **Resolution** | 1344 × 756 px |
| **Frame rate** | 8 fps |
| **Duration** | ~58 seconds  (464 frames) |
| **Category** | Multi-court basketball event with 20+ people |

---

## Project Structure

```
sports_tracker/
├── src/
│   ├── pipeline.py        # Main CLI entry point
│   ├── detector.py        # Aerial colour-blob + MOG2 detector
│   ├── tracker.py         # ByteTrack-style Kalman + Hungarian tracker
│   ├── visualizer.py      # Bounding boxes, IDs, trails, stats, heatmap
│   ├── analytics.py       # Statistics collection and Matplotlib charts
│   └── __init__.py
├── output/                # Generated output files (after running)
│   ├── tracked_output.mp4
│   ├── heatmap.jpg
│   ├── trajectory_map.jpg
│   ├── count_over_time.png
│   ├── id_lifetimes.png
│   ├── displacement.png
│   ├── stats.json
│   └── screenshots/
├── assets/
│   └── source_video.mp4   # Put your video here
├── reports/
│   └── technical_report.md
├── requirements.txt
└── README.md              ← you are here
```

---

## Installation

### Requirements
- Python 3.10 or higher
- pip

### Steps

```bash
# 1. Unzip and enter the project directory
cd sports_tracker

# 2. (Recommended) Create a virtual environment
python -m venv venv
source venv/bin/activate        # Linux / macOS
# venv\Scripts\activate.bat    # Windows

# 3. Install dependencies
pip install -r requirements.txt
```

### requirements.txt
```
opencv-python>=4.8.0
filterpy>=1.4.5
lap>=0.4.0
scipy>=1.10.0
numpy>=1.24.0
matplotlib>=3.7.0
```

---

## How to Run

### Basic run (uses provided video)
```bash
python src/pipeline.py --video "assets/source_video.mp4"
```

### Full run with all optional features
```bash
python src/pipeline.py \
    --video "assets/source_video.mp4" \
    --heatmap \
    --count_bar \
    --out output/
```

### Run on a different video
```bash
python src/pipeline.py --video "path/to/any_video.mp4"
```

### Download from YouTube and run (requires yt-dlp)
```bash
pip install yt-dlp
python src/pipeline.py --url "https://www.youtube.com/watch?v=..."
```

---

## CLI Arguments

| Argument | Default | Description |
|----------|---------|-------------|
| `--video` | — | Path to local video file *(required)* |
| `--url` | — | Public video URL (alternative to --video) |
| `--out` | `output/` | Output directory |
| `--skip` | `1` | Process every N-th frame (1 = all frames) |
| `--max_frames` | `0` | Limit frames processed (0 = whole video) |
| `--max_age` | `40` | Frames a track survives without detection |
| `--min_hits` | `3` | Detections before an ID label is shown |
| `--heatmap` | off | Overlay live heatmap on output video |
| `--no_trajectory` | off | Disable trajectory tail lines |
| `--count_bar` | off | Add count sparkline at bottom of video |
| `--debug` | off | Save foreground-mask debug video |

---

## Output Files

| File | Description |
|------|-------------|
| `tracked_output.mp4` | Annotated video: bounding boxes + persistent IDs + trajectory tails |
| `heatmap.jpg` | Movement density heatmap (Gaussian, overlaid on first frame) |
| `trajectory_map.jpg` | All track paths drawn on first frame |
| `count_over_time.png` | Line chart: active track count vs time |
| `id_lifetimes.png` | Gantt chart: each ID's start/end time |
| `displacement.png` | Bar chart: total displacement per track |
| `stats.json` | Full numerical statistics |
| `screenshots/` | Sample annotated frames |

---

## Pipeline Results (on provided video)

| Metric | Value |
|--------|-------|
| Total unique IDs assigned | **21** |
| Max simultaneous tracks | **16** |
| Mean active per frame | **8.6** |
| Median track lifetime | **14.4 s** |
| Mean track lifetime | **23.9 s** |
| Processing speed | **~8 fps** (real-time on CPU) |

---

## Technical Design

### Detection: Colour-Blob + MOG2

Since this is an **aerial view** of a brightly coloured basketball court (red + blue surfaces), traditional pedestrian detectors (HOG, neural networks expecting upright-person silhouettes) perform poorly. Instead:

1. **Colour segmentation** — HSV ranges for the known court colours (red, blue, white lines) are masked out; remaining pixels are candidate foreground
2. **MOG2 background subtractor** — provides a complementary motion mask to catch players standing on non-court areas
3. **Contour extraction** — connected foreground regions are extracted and filtered by area (350–14,000 px²) and aspect ratio (0.25–4.5)
4. **NMS** — IoU-based non-maximum suppression removes duplicate blobs

This approach requires **zero external model weights** and runs at real-time speed on CPU.

### Tracking: ByteTrack-inspired Kalman + Hungarian

Each track maintains a **7-DOF Kalman filter** with state:

```
[cx, cy, area, aspect_ratio, vx, vy, v_area]
```

Matching is done in **two rounds** per frame:

```
Round 1 → High-confidence detections (≥0.50)  vs  All active tracks
           Cost = 0.65 × (1 − IoU) + 0.35 × Appearance cost

Round 2 → Low-confidence detections (≥0.15)   vs  Unmatched tracks
           Cost = IoU only
```

The Hungarian algorithm (scipy `linear_sum_assignment`) finds the globally optimal assignment. Tracks survive up to `max_age=40` frames without a match (predicted by the Kalman filter), allowing re-identification after brief occlusion.

### Appearance Re-ID

Each track holds an exponentially-smoothed **96-D HSV colour histogram** (32 bins × 3 channels, α=0.25 EMA). Histogram intersection similarity forms the appearance cost term. This helps disambiguate nearby players despite the aerial viewpoint.

---

## Assumptions

1. The court surface colours (red, blue) are relatively stable — brief lighting changes are tolerated
2. People occupy areas of 350–14,000 px² at this camera height and resolution
3. The camera is mostly static (very slow pan at most)
4. A track is "confirmed" after 3 consecutive detections (`min_hits=3`)

---

## Limitations

1. **ID switches at heavy occlusion** — when multiple players cluster tightly and separate, IDs can swap; HSV histograms partially mitigate this but cannot always resolve identical-clothing players
2. **Green background zone** — the upper portion of the frame (trees, grass, scoreboard) is masked but occasionally produces false detections near the boundary fence; a tighter ROI would help
3. **Stationary players** — players sitting on the sidelines may be dropped by the background subtractor's motion cue; the colour-segmentation path still catches most of them
4. **No ball tracking** — the basketball is far too small and fast to be reliably detected with this approach
5. **Aerial-specific** — the colour-blob detector is tuned for red/blue basketball courts; it would need recalibration for a different venue or sport

---

## Possible Improvements

| Area | Approach |
|------|----------|
| **Detection** | Fine-tune YOLOv8 on an aerial sports dataset (e.g. SoccerNet-Tracking, MTSD) |
| **Re-ID** | Replace HSV histogram with an OSNet or BoT-SORT deep appearance embedding |
| **Camera motion** | Estimate frame-to-frame homography and compensate in the Kalman prediction step |
| **Speed estimation** | Calibrate pixel-to-metre scale using known court dimensions (28 m × 15 m for FIBA) |
| **Team clustering** | K-means on jersey colour histograms to auto-assign team labels |
| **Bird's-eye view** | Compute a court homography to project detections to a top-down 2D map |
| **Evaluation** | Compute HOTA / MOTA / IDF1 against a manually annotated ground-truth for a clip |

---

## References

- Zhang, Y. et al. (2022). *ByteTrack: Multi-Object Tracking by Associating Every Detection Box.* ECCV 2022. [arXiv:2110.06864]
- Bewley, A. et al. (2016). *SORT: Simple Online and Realtime Tracking.* ICASSP 2016.
- Zablotskii, A. (2015). *Background subtraction with MOG2.* OpenCV documentation.
- Labbe, R. (2014). *FilterPy: Kalman Filters in Python.* https://github.com/rlabbe/filterpy
