"""
detector.py
-----------
Multi-method person detector optimised for aerial / top-down sports footage.

Strategy:
  1. Primary:  Colour-based segmentation  (court background removal → blob extraction)
               → Best for aerial view where bodies contrast against coloured court
  2. Fallback: HOG + SVM pedestrian detector (OpenCV built-in)

The colour-blob approach is specifically suited to this video:
  - Red/blue basketball court is a stable, known background
  - Players contrast clearly against the court
  - Works without any external model weights

Detection output is a list of (x1, y1, x2, y2, confidence) arrays compatible
with the ByteTracker API.
"""

from __future__ import annotations
import cv2
import numpy as np


# ─────────────────────────────────────────────────────────────────────────────
# Colour ranges for court background (HSV)
# ─────────────────────────────────────────────────────────────────────────────
COURT_RED_LOWER1  = np.array([0,   80, 60])
COURT_RED_UPPER1  = np.array([12, 255, 255])
COURT_RED_LOWER2  = np.array([155, 80, 60])
COURT_RED_UPPER2  = np.array([180, 255, 255])
COURT_BLUE_LOWER  = np.array([88,  60, 60])
COURT_BLUE_UPPER  = np.array([135, 255, 255])
COURT_WHITE_LOWER = np.array([0,   0, 170])
COURT_WHITE_UPPER = np.array([180, 40, 255])
BACKGROUND_GREEN_LOWER = np.array([32, 30, 30])
BACKGROUND_GREEN_UPPER = np.array([90, 255, 200])


class AerialSportsDetector:
    """
    Detects players in aerial/drone sports footage using colour segmentation.

    Parameters
    ----------
    min_area       : minimum blob area (px²) to be a person
    max_area       : maximum blob area (px²)
    min_aspect     : minimum h/w ratio (persons are taller than wide)
    max_aspect     : maximum h/w ratio
    nms_thresh     : IoU threshold for Non-Maximum Suppression
    conf_base      : base confidence assigned to colour-blob detections
    use_hog        : whether to add HOG detections on top (slow but can catch missed)
    """

    def __init__(
        self,
        min_area: int = 350,
        max_area: int = 14000,
        min_aspect: float = 0.25,
        max_aspect: float = 4.5,
        nms_thresh: float = 0.35,
        conf_base: float = 0.6,
        use_hog: bool = False,
    ):
        self.min_area   = min_area
        self.max_area   = max_area
        self.min_aspect = min_aspect
        self.max_aspect = max_aspect
        self.nms_thresh = nms_thresh
        self.conf_base  = conf_base
        self.use_hog    = use_hog

        # Background subtractor for motion-based cues (secondary)
        self.bg_sub = cv2.createBackgroundSubtractorMOG2(
            history=100, varThreshold=40, detectShadows=False
        )

        if use_hog:
            self.hog = cv2.HOGDescriptor()
            self.hog.setSVMDetector(cv2.HOGDescriptor_getDefaultPeopleDetector())

        print("[Detector] AerialSportsDetector initialised")
        print(f"  min_area={min_area}, max_area={max_area}, use_hog={use_hog}")

    # ─────────────────────────────────────────────────────────────────────────
    def detect(
        self,
        frame: np.ndarray,
        roi: tuple[int, int, int, int] | None = None,
    ) -> tuple[np.ndarray, np.ndarray]:
        """
        Detect persons in frame.

        Parameters
        ----------
        frame : BGR image
        roi   : optional (x1,y1,x2,y2) region-of-interest; restrict detection area

        Returns
        -------
        boxes  : (N, 4) float32 [x1, y1, x2, y2]
        scores : (N,)   float32 confidence
        """
        h, w = frame.shape[:2]

        # ── 1. Colour segmentation ────────────────────────────────────────
        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)

        # Mask out known court background colours
        m_r1  = cv2.inRange(hsv, COURT_RED_LOWER1,  COURT_RED_UPPER1)
        m_r2  = cv2.inRange(hsv, COURT_RED_LOWER2,  COURT_RED_UPPER2)
        m_b   = cv2.inRange(hsv, COURT_BLUE_LOWER,  COURT_BLUE_UPPER)
        m_w   = cv2.inRange(hsv, COURT_WHITE_LOWER,  COURT_WHITE_UPPER)
        m_g   = cv2.inRange(hsv, BACKGROUND_GREEN_LOWER, BACKGROUND_GREEN_UPPER)

        court_mask = cv2.bitwise_or(m_r1, cv2.bitwise_or(m_r2, cv2.bitwise_or(m_b, m_w)))
        bg_mask    = cv2.bitwise_or(court_mask, m_g)

        fg_mask = cv2.bitwise_not(bg_mask)

        # ── 2. Background subtractor (motion cue)  ────────────────────────
        motion_mask = self.bg_sub.apply(frame)
        motion_mask = cv2.threshold(motion_mask, 200, 255, cv2.THRESH_BINARY)[1]

        # Dilate motion mask slightly so stationary players still get found
        # via colour alone
        combined = cv2.bitwise_or(fg_mask, cv2.dilate(motion_mask, None, iterations=2))

        # ── 3. Morphological cleanup ─────────────────────────────────────
        k_open  = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (4, 4))
        k_close = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (9, 9))
        combined = cv2.morphologyEx(combined, cv2.MORPH_OPEN,  k_open)
        combined = cv2.morphologyEx(combined, cv2.MORPH_CLOSE, k_close)

        # ── 4. Contour extraction ─────────────────────────────────────────
        contours, _ = cv2.findContours(
            combined, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE
        )

        boxes, scores = [], []
        for cnt in contours:
            area = cv2.contourArea(cnt)
            if area < self.min_area or area > self.max_area:
                continue
            x, y, bw, bh = cv2.boundingRect(cnt)
            aspect = bh / max(bw, 1)
            if not (self.min_aspect <= aspect <= self.max_aspect):
                continue
            # Exclude ROI boundaries and board/pole false positives
            if roi:
                rx1, ry1, rx2, ry2 = roi
                if x < rx1 or y < ry1 or x + bw > rx2 or y + bh > ry2:
                    continue
            # Confidence: larger, more aspect-correct blobs get higher conf
            size_score = min(area / 3000.0, 1.0)
            asp_score  = 1.0 - abs(aspect - 1.8) / 2.5
            conf       = float(np.clip(self.conf_base * 0.5 + size_score * 0.3 + asp_score * 0.2, 0.1, 0.99))
            boxes.append([float(x), float(y), float(x + bw), float(y + bh)])
            scores.append(conf)

        # ── 5. Optional: HOG detections  ─────────────────────────────────
        if self.use_hog:
            scale = 0.5
            small = cv2.resize(frame, (0, 0), fx=scale, fy=scale)
            rects, weights = self.hog.detectMultiScale(
                small, winStride=(8, 8), padding=(8, 8), scale=1.05,
                hitThreshold=-0.3,
            )
            for (rx, ry, rw, rh), wt in zip(rects, weights):
                boxes.append([
                    float(rx / scale), float(ry / scale),
                    float((rx + rw) / scale), float((ry + rh) / scale),
                ])
                scores.append(float(np.clip(wt[0] * 0.5 + 0.5, 0.1, 0.99)))

        if not boxes:
            return np.zeros((0, 4), dtype=np.float32), np.zeros(0, dtype=np.float32)

        boxes_arr  = np.array(boxes,  dtype=np.float32)
        scores_arr = np.array(scores, dtype=np.float32)

        # ── 6. NMS ────────────────────────────────────────────────────────
        keep = self._nms(boxes_arr, scores_arr, self.nms_thresh)
        return boxes_arr[keep], scores_arr[keep]

    # ─────────────────────────────────────────────────────────────────────────
    @staticmethod
    def _nms(boxes: np.ndarray, scores: np.ndarray, thresh: float) -> np.ndarray:
        if len(boxes) == 0:
            return np.array([], dtype=int)
        bboxes_cv = boxes[:, :4].tolist()
        idx = cv2.dnn.NMSBoxes(bboxes_cv, scores.tolist(), 0.0, thresh)
        if len(idx) == 0:
            return np.array([], dtype=int)
        return idx.flatten()

    def get_foreground_mask(self, frame: np.ndarray) -> np.ndarray:
        """Return the foreground mask (for debugging / visualisation)."""
        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
        m_r1 = cv2.inRange(hsv, COURT_RED_LOWER1, COURT_RED_UPPER1)
        m_r2 = cv2.inRange(hsv, COURT_RED_LOWER2, COURT_RED_UPPER2)
        m_b  = cv2.inRange(hsv, COURT_BLUE_LOWER,  COURT_BLUE_UPPER)
        m_w  = cv2.inRange(hsv, COURT_WHITE_LOWER,  COURT_WHITE_UPPER)
        m_g  = cv2.inRange(hsv, BACKGROUND_GREEN_LOWER, BACKGROUND_GREEN_UPPER)
        court = cv2.bitwise_or(m_r1, cv2.bitwise_or(m_r2, cv2.bitwise_or(m_b, m_w)))
        bg    = cv2.bitwise_or(court, m_g)
        return cv2.bitwise_not(bg)
