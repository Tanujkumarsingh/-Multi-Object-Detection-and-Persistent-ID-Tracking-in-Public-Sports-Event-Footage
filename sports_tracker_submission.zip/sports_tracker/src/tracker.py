"""
tracker.py
----------
ByteTrack-inspired multi-object tracker.

Architecture:
  - Each track maintains a 7-DOF Kalman filter  [cx, cy, area, r, vx, vy, v_area]
  - Two-round Hungarian matching:
      Round 1 → high-confidence detections vs all active tracks  (IoU + appearance)
      Round 2 → low-confidence detections  vs unmatched tracks   (IoU only)
  - Appearance model: exponentially-smoothed HSV colour histogram (96-D)
  - Tracks promoted after min_hits confirmations; deleted after max_age misses
"""

from __future__ import annotations

import numpy as np
from scipy.optimize import linear_sum_assignment
from filterpy.kalman import KalmanFilter
import cv2
from dataclasses import dataclass, field


# ─────────────────────────────────────────────────────────────────────────────
# Coordinate helpers
# ─────────────────────────────────────────────────────────────────────────────
def _xyxy_to_z(bbox: np.ndarray) -> np.ndarray:
    """[x1,y1,x2,y2] → column vector [cx, cy, area, ratio]"""
    w  = bbox[2] - bbox[0]
    h  = bbox[3] - bbox[1]
    cx = bbox[0] + w / 2.0
    cy = bbox[1] + h / 2.0
    s  = w * h
    r  = w / float(h + 1e-6)
    return np.array([[cx], [cy], [s], [r]], dtype=float)


def _z_to_xyxy(x: np.ndarray) -> np.ndarray:
    """State vector → [x1,y1,x2,y2]"""
    x = x.flatten()
    s = float(x[2])
    r = float(x[3])
    w = float(np.sqrt(max(s * r, 1)))
    h = float(max(s / (w + 1e-6), 1))
    cx, cy = float(x[0]), float(x[1])
    return np.array([cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2])


# ─────────────────────────────────────────────────────────────────────────────
# Single Track
# ─────────────────────────────────────────────────────────────────────────────
class Track:
    """One tracked object."""

    _id_counter: int = 0

    @classmethod
    def reset_counter(cls):
        cls._id_counter = 0

    def __init__(self, bbox: np.ndarray, frame_id: int, appearance: np.ndarray | None = None):
        Track._id_counter += 1
        self.id   = Track._id_counter
        self.hits = 1
        self.hit_streak     = 1
        self.time_since_update = 0
        self.age  = 0
        self.birth_frame = frame_id

        # Appearance: EMA of HSV histogram
        self.appearance: np.ndarray | None = appearance

        # History of centre-points for trajectory drawing
        self.centres: list[tuple[int, int]] = []
        cx = int((bbox[0] + bbox[2]) / 2)
        cy = int((bbox[1] + bbox[3]) / 2)
        self.centres.append((cx, cy))

        self._build_kalman(bbox)

    # ── Kalman filter ─────────────────────────────────────────────────────
    def _build_kalman(self, bbox: np.ndarray):
        kf = KalmanFilter(dim_x=7, dim_z=4)
        # State transition (constant velocity)
        kf.F = np.array([
            [1,0,0,0,1,0,0],
            [0,1,0,0,0,1,0],
            [0,0,1,0,0,0,1],
            [0,0,0,1,0,0,0],
            [0,0,0,0,1,0,0],
            [0,0,0,0,0,1,0],
            [0,0,0,0,0,0,1],
        ], dtype=float)
        # Measurement function
        kf.H = np.array([
            [1,0,0,0,0,0,0],
            [0,1,0,0,0,0,0],
            [0,0,1,0,0,0,0],
            [0,0,0,1,0,0,0],
        ], dtype=float)
        kf.R[2:, 2:] *= 10.0
        kf.P[4:, 4:] *= 1000.0
        kf.P         *= 10.0
        kf.Q[-1, -1] *= 0.01
        kf.Q[4:, 4:] *= 0.01
        kf.x[:4] = _xyxy_to_z(bbox)
        self.kf = kf

    def predict(self) -> np.ndarray:
        if self.kf.x[6] + self.kf.x[2] <= 0:
            self.kf.x[6] = 0.0
        self.kf.predict()
        self.age += 1
        if self.time_since_update > 0:
            self.hit_streak = 0
        self.time_since_update += 1
        return _z_to_xyxy(self.kf.x)

    def update(self, bbox: np.ndarray, appearance: np.ndarray | None = None):
        self.time_since_update = 0
        self.hits       += 1
        self.hit_streak += 1
        self.kf.update(_xyxy_to_z(bbox))

        cx = int((bbox[0] + bbox[2]) / 2)
        cy = int((bbox[1] + bbox[3]) / 2)
        self.centres.append((cx, cy))
        if len(self.centres) > 120:
            self.centres.pop(0)

        # EMA appearance update
        if appearance is not None:
            if self.appearance is None:
                self.appearance = appearance.copy()
            else:
                alpha = 0.25
                self.appearance = (1 - alpha) * self.appearance + alpha * appearance

    def get_bbox(self) -> np.ndarray:
        return _z_to_xyxy(self.kf.x)


# ─────────────────────────────────────────────────────────────────────────────
# IoU helpers
# ─────────────────────────────────────────────────────────────────────────────
def _iou_batch(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    """IoU matrix (n×m) between two sets of boxes [x1,y1,x2,y2]."""
    if len(a) == 0 or len(b) == 0:
        return np.zeros((len(a), len(b)))
    x1 = np.maximum(a[:, 0:1], b[:, 0])
    y1 = np.maximum(a[:, 1:2], b[:, 1])
    x2 = np.minimum(a[:, 2:3], b[:, 2])
    y2 = np.minimum(a[:, 3:4], b[:, 3])
    inter = np.maximum(0, x2 - x1) * np.maximum(0, y2 - y1)
    area_a = (a[:, 2] - a[:, 0]) * (a[:, 3] - a[:, 1])
    area_b = (b[:, 2] - b[:, 0]) * (b[:, 3] - b[:, 1])
    union  = area_a[:, None] + area_b[None, :] - inter
    return inter / (union + 1e-6)


def _appearance_cost(tracks: list[Track], apps: list[np.ndarray | None]) -> np.ndarray:
    n, m = len(tracks), len(apps)
    cost = np.ones((n, m), dtype=float)
    for i, trk in enumerate(tracks):
        if trk.appearance is None:
            continue
        for j, app in enumerate(apps):
            if app is None:
                continue
            sim = cv2.compareHist(
                trk.appearance.astype(np.float32),
                app.astype(np.float32),
                cv2.HISTCMP_INTERSECT,
            )
            cost[i, j] = 1.0 - float(np.clip(sim, 0, 1))
    return cost


def _hungarian(cost: np.ndarray, thresh: float):
    """Return (matches, unmatched_rows, unmatched_cols)."""
    if cost.size == 0:
        return [], list(range(cost.shape[0])), list(range(cost.shape[1]))
    rows, cols = linear_sum_assignment(cost)
    matched, mr, mc = [], set(), set()
    for r, c in zip(rows, cols):
        if cost[r, c] <= thresh:
            matched.append((r, c))
            mr.add(r); mc.add(c)
    unmatched_r = [i for i in range(cost.shape[0]) if i not in mr]
    unmatched_c = [j for j in range(cost.shape[1]) if j not in mc]
    return matched, unmatched_r, unmatched_c


# ─────────────────────────────────────────────────────────────────────────────
# Appearance extraction helper
# ─────────────────────────────────────────────────────────────────────────────
def extract_appearance(frame: np.ndarray, bbox: np.ndarray, bins: int = 32) -> np.ndarray | None:
    """32-bin HSV histogram per channel, L2-normalised."""
    if frame is None:
        return None
    x1, y1, x2, y2 = [int(v) for v in bbox]
    fh, fw = frame.shape[:2]
    x1, y1 = max(0, x1), max(0, y1)
    x2, y2 = min(fw, x2), min(fh, y2)
    if (x2 - x1) < 5 or (y2 - y1) < 5:
        return None
    crop = frame[y1:y2, x1:x2]
    hsv  = cv2.cvtColor(crop, cv2.COLOR_BGR2HSV)
    parts = []
    for ch, rng in [(0, [0, 180]), (1, [0, 256]), (2, [0, 256])]:
        h = cv2.calcHist([hsv], [ch], None, [bins], rng)
        cv2.normalize(h, h, 0, 1, cv2.NORM_MINMAX)
        parts.append(h.flatten())
    return np.concatenate(parts).astype(np.float32)


# ─────────────────────────────────────────────────────────────────────────────
# Main Tracker
# ─────────────────────────────────────────────────────────────────────────────
class ByteTracker:
    """
    ByteTrack-style multi-object tracker.

    Parameters
    ----------
    max_age          : frames a track survives without a detection
    min_hits         : detections before a track ID is displayed
    iou_threshold    : IoU gate for matching
    high_conf_thresh : detections ≥ this go to round-1 matching
    low_conf_thresh  : detections ≥ this go to round-2 matching
    use_appearance   : blend appearance cost with IoU cost
    appearance_weight: weight of appearance vs IoU (0-1)
    """

    def __init__(
        self,
        max_age: int          = 30,
        min_hits: int         = 3,
        iou_threshold: float  = 0.25,
        high_conf_thresh: float = 0.45,
        low_conf_thresh: float  = 0.10,
        use_appearance: bool  = True,
        appearance_weight: float = 0.35,
    ):
        self.max_age          = max_age
        self.min_hits         = min_hits
        self.iou_thresh       = iou_threshold
        self.high_conf        = high_conf_thresh
        self.low_conf         = low_conf_thresh
        self.use_appearance   = use_appearance
        self.app_weight       = appearance_weight

        self.tracks: list[Track] = []
        self.frame_count = 0
        Track.reset_counter()

    def update(
        self,
        boxes:   np.ndarray,   # (N,4) [x1,y1,x2,y2]
        scores:  np.ndarray,   # (N,)
        frame:   np.ndarray,   # BGR image for appearance
    ) -> list[dict]:
        """Process one frame. Returns list of active track dicts."""
        self.frame_count += 1

        # Split detections by confidence
        hi  = scores >= self.high_conf
        lo  = (scores >= self.low_conf) & ~hi
        dh, sh = boxes[hi],  scores[hi]
        dl, sl = boxes[lo],  scores[lo]

        apps_h = [extract_appearance(frame, b) for b in dh]
        apps_l = [extract_appearance(frame, b) for b in dl]

        # Predict all existing tracks
        pred_bboxes = [t.predict() for t in self.tracks]

        # ── Round 1: high-conf dets vs all tracks ───────────────────────
        matched1, unm_t1, unm_dh = self._match(
            self.tracks, pred_bboxes, dh, apps_h
        )
        for ti, di in matched1:
            self.tracks[ti].update(dh[di], apps_h[di])

        # ── Round 2: low-conf dets vs remaining tracks ──────────────────
        rem_tracks = [self.tracks[i] for i in unm_t1]
        rem_preds  = [pred_bboxes[i]  for i in unm_t1]
        matched2, unm_t2_local, _ = self._match(
            rem_tracks, rem_preds, dl, apps_l, appearance=False
        )
        for local_ti, di in matched2:
            real_ti = unm_t1[local_ti]
            self.tracks[real_ti].update(dl[di], apps_l[di])

        # ── Spawn new tracks from unmatched high-conf detections ─────────
        for di in unm_dh:
            self.tracks.append(Track(dh[di], self.frame_count, apps_h[di]))

        # ── Remove dead tracks ───────────────────────────────────────────
        self.tracks = [t for t in self.tracks if t.time_since_update <= self.max_age]

        # ── Collect output ───────────────────────────────────────────────
        results = []
        for t in self.tracks:
            if t.hits >= self.min_hits or self.frame_count <= self.min_hits:
                results.append({
                    "id":      t.id,
                    "bbox":    t.get_bbox(),
                    "hits":    t.hits,
                    "age":     t.age,
                    "centres": list(t.centres),
                    "streak":  t.hit_streak,
                })
        return results

    # ─────────────────────────────────────────────────────────────────────
    def _match(
        self,
        tracks:    list[Track],
        preds:     list[np.ndarray],
        dets:      np.ndarray,
        apps:      list,
        appearance: bool = True,
    ):
        if len(tracks) == 0 or len(dets) == 0:
            return [], list(range(len(tracks))), list(range(len(dets)))

        pred_arr = np.array(preds)
        iou      = _iou_batch(pred_arr, dets)
        iou_cost = 1.0 - iou

        if appearance and self.use_appearance:
            app_cost = _appearance_cost(tracks, apps)
            w = self.app_weight
            cost = (1 - w) * iou_cost + w * app_cost
        else:
            cost = iou_cost

        return _hungarian(cost, 1 - self.iou_thresh)
