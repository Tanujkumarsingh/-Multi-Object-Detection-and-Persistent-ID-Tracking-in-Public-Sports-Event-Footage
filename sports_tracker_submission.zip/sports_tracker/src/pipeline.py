"""
pipeline.py
-----------
Main CLI entry point for the Multi-Object Detection & Persistent ID Tracking pipeline.

Usage:
    python src/pipeline.py --video "path/to/video.mp4" [options]
    python src/pipeline.py --url  "https://youtube.com/..." [options]

Options:
    --video         Path to local video file
    --url           Public video URL (requires yt-dlp)
    --out           Output directory (default: output/)
    --skip          Process every N-th frame (default: 1)
    --max_frames    Max frames to process (0 = all)
    --max_age       Tracker max_age frames (default: 40)
    --min_hits      Min confirmations to show ID (default: 3)
    --heatmap       Overlay heatmap on output video
    --no_trajectory Disable trajectory tails
    --count_bar     Add count sparkline to video
    --debug         Save foreground-mask debug video
"""

from __future__ import annotations

import argparse
import os
import sys
import time
from pathlib import Path

import cv2
import numpy as np

sys.path.insert(0, str(Path(__file__).parent))
from detector   import AerialSportsDetector
from tracker    import ByteTracker
from visualizer import draw_tracks, draw_stats, draw_count_sparkline, HeatmapAccumulator
from analytics  import Analytics


# ─────────────────────────────────────────────────────────────────────────────
def parse_args():
    p = argparse.ArgumentParser(description="Multi-Object Sports Tracker")
    src = p.add_mutually_exclusive_group(required=True)
    src.add_argument("--video", type=str)
    src.add_argument("--url",   type=str)
    p.add_argument("--out",          default="output")
    p.add_argument("--skip",         type=int,   default=1)
    p.add_argument("--max_frames",   type=int,   default=0)
    p.add_argument("--max_age",      type=int,   default=40)
    p.add_argument("--min_hits",     type=int,   default=3)
    p.add_argument("--heatmap",      action="store_true")
    p.add_argument("--no_trajectory",action="store_true")
    p.add_argument("--count_bar",    action="store_true")
    p.add_argument("--debug",        action="store_true")
    return p.parse_args()


# ─────────────────────────────────────────────────────────────────────────────
def run(cfg: dict) -> dict:
    os.makedirs(cfg["out"], exist_ok=True)

    # ── Video source ─────────────────────────────────────────────────────
    video_path = cfg.get("video_path")

    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        raise IOError(f"Cannot open: {video_path}")

    fps_in = cap.get(cv2.CAP_PROP_FPS) or 25.0
    W      = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    H      = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    N      = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    print(f"[Pipeline] {W}×{H}  {fps_in:.1f}fps  {N} frames  ({N/fps_in:.1f}s)")

    # ── Components ──────────────────────────────────────────────────────
    detector = AerialSportsDetector(
        min_area=350, max_area=14000,
        min_aspect=0.25, max_aspect=4.5,
        nms_thresh=0.30,
        conf_base=0.65,
        use_hog=False,
    )
    tracker = ByteTracker(
        max_age=cfg["max_age"],
        min_hits=cfg["min_hits"],
        iou_threshold=0.22,
        high_conf_thresh=0.50,
        low_conf_thresh=0.15,
        use_appearance=True,
        appearance_weight=0.35,
    )
    analytics  = Analytics(fps=fps_in)
    heatmap    = HeatmapAccumulator(H, W)

    # ── Writers ─────────────────────────────────────────────────────────
    out_h = H + (44 if cfg["count_bar"] else 0)
    fourcc = cv2.VideoWriter_fourcc(*"mp4v")
    out_path = os.path.join(cfg["out"], "tracked_output.mp4")
    writer   = cv2.VideoWriter(out_path, fourcc, fps_in, (W, out_h))

    if cfg.get("debug"):
        dbg_path = os.path.join(cfg["out"], "debug_fg.mp4")
        dbg_writer = cv2.VideoWriter(dbg_path, fourcc, fps_in, (W, H))
    else:
        dbg_writer = None

    # ── Main loop ────────────────────────────────────────────────────────
    frame_idx   = 0
    proc_frames = 0
    total_ids   = 0
    fps_disp    = fps_in
    last_res: list[dict] = []
    count_hist: list[int] = []
    first_frame = None
    t0 = time.time()

    print(f"[Pipeline] Processing … skip={cfg['skip']}")

    while True:
        ret, frame = cap.read()
        if not ret:
            break
        if cfg["max_frames"] and proc_frames >= cfg["max_frames"]:
            break

        frame_idx += 1

        if first_frame is None:
            first_frame = frame.copy()

        # ── Skip logic ────────────────────────────────────────────────
        if frame_idx % cfg["skip"] != 0:
            ann = frame.copy()
            ann = draw_tracks(ann, last_res, draw_trajectory=not cfg["no_trajectory"])
            ann = draw_stats(ann, frame_idx, fps_disp, len(last_res), total_ids)
            if cfg["count_bar"]:
                ann = draw_count_sparkline(ann, count_hist or [0])
            writer.write(ann)
            continue

        # ── Detect ───────────────────────────────────────────────────
        boxes, scores = detector.detect(frame)

        # ── Track ────────────────────────────────────────────────────
        results = tracker.update(boxes, scores, frame)

        # ── Analytics / heatmap ──────────────────────────────────────
        analytics.update(frame_idx, results)
        total_ids  = len(analytics.records)
        count_hist = analytics.count_history
        heatmap.update(results)

        # ── Annotate ─────────────────────────────────────────────────
        ann = frame.copy()
        if cfg["heatmap"]:
            ann = heatmap.overlay(ann, alpha=0.30)
        ann = draw_tracks(ann, results, draw_trajectory=not cfg["no_trajectory"])
        elapsed = time.time() - t0
        if elapsed > 0:
            fps_disp = proc_frames / elapsed
        ann = draw_stats(ann, frame_idx, fps_disp, len(results), total_ids)
        if cfg["count_bar"]:
            ann = draw_count_sparkline(ann, count_hist)
        writer.write(ann)

        # Debug mask
        if dbg_writer:
            mask = detector.get_foreground_mask(frame)
            dbg_writer.write(cv2.cvtColor(mask, cv2.COLOR_GRAY2BGR))

        last_res = results
        proc_frames += 1

        if proc_frames % 50 == 0:
            pct = frame_idx / max(N, 1) * 100
            print(f"  [{pct:5.1f}%] frame={frame_idx:4d}  active={len(results):2d}  "
                  f"total_ids={total_ids:2d}  fps={fps_disp:.1f}")

    cap.release()
    writer.release()
    if dbg_writer:
        dbg_writer.release()

    print(f"\n[Pipeline] Output video → {out_path}")

    # ── Save analytics ───────────────────────────────────────────────────
    hm_path = os.path.join(cfg["out"], "heatmap.jpg")
    cv2.imwrite(hm_path, heatmap.get_final_image())

    traj_path = os.path.join(cfg["out"], "trajectory_map.jpg")
    if first_frame is not None:
        analytics.plot_trajectory_map(first_frame, traj_path)

    analytics.plot_count_over_time(os.path.join(cfg["out"], "count_over_time.png"))
    analytics.plot_id_lifetimes(   os.path.join(cfg["out"], "id_lifetimes.png"))
    analytics.plot_displacement(   os.path.join(cfg["out"], "displacement.png"))
    analytics.save_json(           os.path.join(cfg["out"], "stats.json"))

    # ── Summary ──────────────────────────────────────────────────────────
    s = analytics.summary()
    total_time = time.time() - t0
    print(f"\n{'='*56}")
    print(f"  PIPELINE COMPLETE  ({total_time:.1f}s)")
    print(f"{'='*56}")
    for k, v in s.items():
        print(f"  {k:<30}: {v}")
    print(f"{'='*56}\n")
    return s


# ─────────────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    args = parse_args()

    if args.url:
        import subprocess
        os.makedirs("assets", exist_ok=True)
        cmd = ["yt-dlp", "-f", "best[height<=480]/best",
               "--merge-output-format", "mp4",
               "-o", "assets/source_video.%(ext)s",
               "--no-playlist", args.url]
        subprocess.run(cmd, check=True)
        video_path = "assets/source_video.mp4"
    else:
        video_path = args.video

    cfg = dict(
        video_path    = video_path,
        out           = args.out,
        skip          = args.skip,
        max_frames    = args.max_frames,
        max_age       = args.max_age,
        min_hits      = args.min_hits,
        heatmap       = args.heatmap,
        no_trajectory = args.no_trajectory,
        count_bar     = args.count_bar,
        debug         = args.debug,
    )
    run(cfg)
