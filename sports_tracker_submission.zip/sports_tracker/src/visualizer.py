"""
visualizer.py
-------------
Frame annotation utilities: bounding boxes, IDs, trajectory tails,
stats overlay, heatmap, count sparkline.
"""

from __future__ import annotations
import cv2
import numpy as np
import hashlib
import colorsys


# ─────────────────────────────────────────────────────────────────────────────
def _id_colour(tid: int) -> tuple[int, int, int]:
    """Deterministic vivid BGR colour per track ID."""
    h_val = int(hashlib.md5(str(tid).encode()).hexdigest(), 16)
    hue   = (h_val % 360) / 360.0
    r, g, b = colorsys.hsv_to_rgb(hue, 0.90, 0.95)
    return int(b * 255), int(g * 255), int(r * 255)


# ─────────────────────────────────────────────────────────────────────────────
def draw_tracks(
    frame: np.ndarray,
    results: list[dict],
    draw_trajectory: bool = True,
    trail_length: int = 80,
    box_thickness: int = 2,
) -> np.ndarray:
    """Draw bounding boxes, IDs, and trajectory tails."""
    for trk in results:
        tid    = trk["id"]
        bbox   = trk["bbox"]
        hist   = trk.get("centres", [])
        color  = _id_colour(tid)

        x1, y1, x2, y2 = [int(v) for v in bbox]

        # Trajectory tail
        if draw_trajectory and len(hist) > 1:
            pts = hist[-trail_length:]
            for i in range(1, len(pts)):
                alpha     = i / len(pts)
                t_col     = tuple(int(c * alpha * 0.9 + 30) for c in color)
                thickness = max(1, int(box_thickness * alpha))
                cv2.line(frame, pts[i - 1], pts[i], t_col, thickness, cv2.LINE_AA)

        # Bounding box (semi-transparent fill)
        overlay = frame.copy()
        cv2.rectangle(overlay, (x1, y1), (x2, y2), color, -1)
        cv2.addWeighted(overlay, 0.08, frame, 0.92, 0, frame)
        cv2.rectangle(frame, (x1, y1), (x2, y2), color, box_thickness, cv2.LINE_AA)

        # ID label
        label = f"#{tid}"
        fs    = 0.55
        (tw, th), bl = cv2.getTextSize(label, cv2.FONT_HERSHEY_DUPLEX, fs, 1)
        lx = x1
        ly = max(y1 - 4, th + 4)
        cv2.rectangle(frame, (lx - 1, ly - th - 4), (lx + tw + 5, ly + 2), color, -1)
        cv2.putText(frame, label, (lx + 2, ly - 1),
                    cv2.FONT_HERSHEY_DUPLEX, fs, (255, 255, 255), 1, cv2.LINE_AA)

    return frame


# ─────────────────────────────────────────────────────────────────────────────
def draw_stats(
    frame: np.ndarray,
    frame_id: int,
    fps: float,
    n_active: int,
    total_ids: int,
) -> np.ndarray:
    lines = [
        f" Frame  : {frame_id}",
        f" FPS    : {fps:.1f}",
        f" Active : {n_active}",
        f" Total  : {total_ids} IDs",
    ]
    x0, y0, lh = 8, 22, 21
    pad = 5
    max_w = max(cv2.getTextSize(l, cv2.FONT_HERSHEY_SIMPLEX, 0.50, 1)[0][0] for l in lines)
    # Dark panel
    cv2.rectangle(frame,
                  (x0 - pad, y0 - lh - 2),
                  (x0 + max_w + pad, y0 + lh * (len(lines) - 1) + pad),
                  (10, 10, 10), -1)
    cv2.rectangle(frame,
                  (x0 - pad, y0 - lh - 2),
                  (x0 + max_w + pad, y0 + lh * (len(lines) - 1) + pad),
                  (60, 200, 60), 1)
    for i, line in enumerate(lines):
        cv2.putText(frame, line, (x0, y0 + i * lh),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.50, (180, 255, 180), 1, cv2.LINE_AA)
    return frame


# ─────────────────────────────────────────────────────────────────────────────
def draw_count_sparkline(
    frame: np.ndarray,
    count_history: list[int],
    bar_height: int = 44,
    max_count: int  = 25,
) -> np.ndarray:
    """Append a count-over-time sparkline bar below the frame."""
    h, w = frame.shape[:2]
    bar  = np.zeros((bar_height, w, 3), dtype=np.uint8)
    bar[:] = (18, 18, 18)
    n = len(count_history)
    if n > 1:
        step = w / n
        for i in range(1, n):
            x1 = int((i - 1) * step)
            x2 = int(i * step)
            v1 = int(count_history[i-1] / max(max_count, 1) * (bar_height - 10))
            v2 = int(count_history[i]   / max(max_count, 1) * (bar_height - 10))
            cv2.line(bar,
                     (x1, bar_height - 4 - v1),
                     (x2, bar_height - 4 - v2),
                     (0, 210, 120), 2, cv2.LINE_AA)
    cur = count_history[-1] if count_history else 0
    cv2.putText(bar, f"Active: {cur}", (6, bar_height - 6),
                cv2.FONT_HERSHEY_SIMPLEX, 0.42, (160, 160, 160), 1)
    return np.vstack([frame, bar])


# ─────────────────────────────────────────────────────────────────────────────
class HeatmapAccumulator:
    """Accumulates centre-point hits and generates a colour heatmap."""

    def __init__(self, height: int, width: int, decay: float = 0.998):
        self.h = height
        self.w = width
        self.decay = decay
        self._map = np.zeros((height, width), dtype=np.float32)
        self._permanent = np.zeros((height, width), dtype=np.float32)

    def update(self, results: list[dict]):
        self._map *= self.decay
        for trk in results:
            bbox = trk["bbox"]
            cx = int(np.clip((bbox[0] + bbox[2]) / 2, 0, self.w - 1))
            cy = int(np.clip((bbox[1] + bbox[3]) / 2, 0, self.h - 1))
            cv2.circle(self._map,      (cx, cy), 14, 1.0, -1)
            cv2.circle(self._permanent,(cx, cy), 14, 1.0, -1)

    def overlay(self, frame: np.ndarray, alpha: float = 0.35) -> np.ndarray:
        norm = cv2.normalize(self._map, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
        hm   = cv2.applyColorMap(norm, cv2.COLORMAP_JET)
        hm   = cv2.resize(hm, (frame.shape[1], frame.shape[0]))
        return cv2.addWeighted(frame, 1 - alpha, hm, alpha, 0)

    def get_final_image(self) -> np.ndarray:
        """Full-accumulation heatmap (no decay), for the summary image."""
        norm = cv2.normalize(self._permanent, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
        return cv2.applyColorMap(norm, cv2.COLORMAP_HOT)
