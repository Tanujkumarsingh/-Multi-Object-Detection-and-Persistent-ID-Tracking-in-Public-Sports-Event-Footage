"""
analytics.py
------------
Collects per-frame statistics and generates summary charts.
"""

from __future__ import annotations

import json
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from dataclasses import dataclass, field


@dataclass
class TrackRecord:
    track_id:    int
    first_frame: int
    last_frame:  int  = 0
    centres:     list = field(default_factory=list)
    bboxes:      list = field(default_factory=list)


class Analytics:
    def __init__(self, fps: float = 25.0):
        self.fps = fps
        self.records: dict[int, TrackRecord] = {}
        self.count_history: list[int] = []

    def update(self, frame_id: int, results: list[dict]):
        self.count_history.append(len(results))
        for trk in results:
            tid  = trk["id"]
            bbox = trk["bbox"]
            cx   = int((bbox[0] + bbox[2]) / 2)
            cy   = int((bbox[1] + bbox[3]) / 2)
            if tid not in self.records:
                self.records[tid] = TrackRecord(tid, frame_id)
            rec = self.records[tid]
            rec.last_frame = frame_id
            rec.centres.append((cx, cy))
            rec.bboxes.append(list(bbox))

    def summary(self) -> dict:
        lifetimes = [(r.last_frame - r.first_frame + 1) / self.fps
                     for r in self.records.values()]
        return {
            "total_unique_ids":    len(self.records),
            "max_simultaneous":    max(self.count_history, default=0),
            "mean_active_per_frame": round(float(np.mean(self.count_history)) if self.count_history else 0, 2),
            "median_lifetime_s":   round(float(np.median(lifetimes)) if lifetimes else 0, 2),
            "mean_lifetime_s":     round(float(np.mean(lifetimes))   if lifetimes else 0, 2),
        }

    # ── Plots ──────────────────────────────────────────────────────────────
    def plot_count_over_time(self, path: str):
        ts = [i / self.fps for i in range(len(self.count_history))]
        fig, ax = plt.subplots(figsize=(13, 3.5))
        ax.fill_between(ts, self.count_history, alpha=0.30, color="#2196F3")
        ax.plot(ts, self.count_history, color="#2196F3", lw=1.5, label="Active tracks")
        ax.set_xlabel("Time (s)", fontsize=11)
        ax.set_ylabel("Active tracks", fontsize=11)
        ax.set_title("Active Track Count Over Time", fontsize=13, fontweight="bold")
        ax.grid(True, alpha=0.25)
        ax.legend()
        fig.tight_layout()
        fig.savefig(path, dpi=130)
        plt.close(fig)
        print(f"[Analytics] {path}")

    def plot_id_lifetimes(self, path: str):
        recs = sorted(self.records.values(), key=lambda r: r.first_frame)
        if not recs:
            return
        fig, ax = plt.subplots(figsize=(14, max(4, len(recs) * 0.28 + 1)))
        cmap = plt.cm.tab20
        for i, rec in enumerate(recs):
            t0 = rec.first_frame / self.fps
            t1 = rec.last_frame  / self.fps
            c  = cmap(rec.track_id % 20 / 20)
            ax.barh(i, t1 - t0, left=t0, height=0.7, color=c, alpha=0.85)
            ax.text(t0 + 0.1, i, f"#{rec.track_id}", va="center", fontsize=7)
        ax.set_xlabel("Time (s)", fontsize=11)
        ax.set_title("Per-Track Lifetime (Gantt)", fontsize=13, fontweight="bold")
        ax.set_yticks([])
        ax.grid(axis="x", alpha=0.25)
        fig.tight_layout()
        fig.savefig(path, dpi=130)
        plt.close(fig)
        print(f"[Analytics] {path}")

    def plot_displacement(self, path: str):
        ids, disps = [], []
        for rec in self.records.values():
            if len(rec.centres) < 2:
                continue
            pts  = np.array(rec.centres, dtype=float)
            disp = float(np.sum(np.linalg.norm(np.diff(pts, axis=0), axis=1)))
            ids.append(rec.track_id)
            disps.append(disp)
        if not disps:
            return
        fig, ax = plt.subplots(figsize=(12, 4))
        colors = plt.cm.viridis(np.array(disps) / max(disps))
        ax.bar(range(len(ids)), disps, color=colors)
        ax.set_xticks(range(len(ids)))
        ax.set_xticklabels([f"#{i}" for i in ids], rotation=75, fontsize=7)
        ax.set_ylabel("Cumulative displacement (px)", fontsize=11)
        ax.set_title("Displacement per Track", fontsize=13, fontweight="bold")
        ax.grid(axis="y", alpha=0.25)
        fig.tight_layout()
        fig.savefig(path, dpi=130)
        plt.close(fig)
        print(f"[Analytics] {path}")

    def plot_trajectory_map(self, bg_frame: np.ndarray, path: str):
        """Draw all trajectory lines on a copy of the first frame."""
        import cv2
        import hashlib, colorsys
        canvas = bg_frame.copy()
        for rec in self.records.values():
            if len(rec.centres) < 2:
                continue
            h_val = int(hashlib.md5(str(rec.track_id).encode()).hexdigest(), 16)
            hue   = (h_val % 360) / 360.0
            r, g, b = colorsys.hsv_to_rgb(hue, 0.85, 0.90)
            color = (int(b*255), int(g*255), int(r*255))
            pts = rec.centres
            for i in range(1, len(pts)):
                cv2.line(canvas, pts[i-1], pts[i], color, 2, cv2.LINE_AA)
        cv2.imwrite(path, canvas)
        print(f"[Analytics] {path}")

    def save_json(self, path: str):
        data = {
            "summary": self.summary(),
            "tracks": [
                {"id": r.track_id,
                 "first_frame": r.first_frame,
                 "last_frame":  r.last_frame,
                 "detections":  len(r.centres)}
                for r in self.records.values()
            ],
            "count_history": self.count_history,
        }
        with open(path, "w") as f:
            json.dump(data, f, indent=2)
        print(f"[Analytics] {path}")
